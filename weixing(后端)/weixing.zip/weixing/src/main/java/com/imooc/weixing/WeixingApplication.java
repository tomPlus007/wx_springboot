package com.imooc.weixing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeixingApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeixingApplication.class, args);
    }

}
